// ES6---------------

export default class Person {
    constructor(name) {
        this.name = name;
    }
    calculateAge(){
        console.log(`Damn im good at coding, made by ${this.name}`)
    }
    calculateAge1(){
        console.log(`Damn im good at coding, made by ${this.names}`)
    }

}
